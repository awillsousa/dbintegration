﻿using System;
using System.Collections.Generic;

namespace efcoremodels.Models
{
    public partial class Estudantes
    {
        public Estudantes()
        {
            EstudantesCursos = new HashSet<EstudantesCursos>();
        }

        public int EstudanteId { get; set; }
        public string Nome { get; set; }
        public int? Idade { get; set; }
        public string Sexo { get; set; }

        public ICollection<EstudantesCursos> EstudantesCursos { get; set; }
    }
}
