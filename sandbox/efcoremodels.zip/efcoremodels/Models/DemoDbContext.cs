﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace efcoremodels.Models
{
    public partial class DemoDbContext : DbContext
    {
        public virtual DbSet<Alunos> Alunos { get; set; }
        public virtual DbSet<Cursos> Cursos { get; set; }
        public virtual DbSet<Estudantes> Estudantes { get; set; }
        public virtual DbSet<EstudantesCursos> EstudantesCursos { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer(@"Data Source=MACORATTI;Initial Catalog=Escola;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Alunos>(entity =>
            {
                entity.Property(e => e.Email).HasMaxLength(150);

                entity.Property(e => e.Foto).HasMaxLength(150);

                entity.Property(e => e.Nascimento).HasColumnType("datetime");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Sexo).HasMaxLength(50);

                entity.Property(e => e.Texto).HasMaxLength(100);
            });

            modelBuilder.Entity<Cursos>(entity =>
            {
                entity.HasKey(e => e.CursoId);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Estudantes>(entity =>
            {
                entity.HasKey(e => e.EstudanteId);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(150);

                entity.Property(e => e.Sexo).HasMaxLength(50);
            });

            modelBuilder.Entity<EstudantesCursos>(entity =>
            {
                entity.HasKey(e => new { e.CursoId, e.EstudanteId });

                entity.HasOne(d => d.Curso)
                    .WithMany(p => p.EstudantesCursos)
                    .HasForeignKey(d => d.CursoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EstudanteCurso_Cursos");

                entity.HasOne(d => d.Estudante)
                    .WithMany(p => p.EstudantesCursos)
                    .HasForeignKey(d => d.EstudanteId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EstudanteCurso_Estudantes");
            });
        }
    }
}
