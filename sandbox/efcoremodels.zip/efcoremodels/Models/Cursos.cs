﻿using System;
using System.Collections.Generic;

namespace efcoremodels.Models
{
    public partial class Cursos
    {
        public Cursos()
        {
            EstudantesCursos = new HashSet<EstudantesCursos>();
        }

        public int CursoId { get; set; }
        public string Nome { get; set; }
        public int? Creditos { get; set; }

        public ICollection<EstudantesCursos> EstudantesCursos { get; set; }
    }
}
