﻿using System;
using System.Collections.Generic;

namespace efcoremodels.Models
{
    public partial class EstudantesCursos
    {
        public int CursoId { get; set; }
        public int EstudanteId { get; set; }

        public Cursos Curso { get; set; }
        public Estudantes Estudante { get; set; }
    }
}
